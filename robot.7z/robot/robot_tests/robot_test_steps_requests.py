# _*_ coding:utf-8 _*_
import requests
from lxml import html
from bs4 import BeautifulSoup as bs



def getEmptyC():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":""}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Please enter a valid serial number")):
        return "\nCase0: Please enter a valid serial number."
    else:
        return 0 



def get_web_data1():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"1"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase1: Please input at least 6 characters"
    else:
        return 0 


def get_web_data2():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"11"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase2: Please input at least 6 characters"
    else:
        return 0 



def get_web_data3():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"111"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase3: Please input at least 6 characters"
    else:
        return 0 



def get_web_data4():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"1111"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase4: Please input at least 6 characters"
    else:
        return 0 


def get_web_data5():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"11111"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase5: Please input at least 6 characters"
    else:
        return 0 


def get_web_data6():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"111111"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Minimum 6 characters required")):
        return "\nCase6: We are sorry, there is no warranty information available about this product, if you need more information about this, please"
    else:
        return 0 



def get_web_data07():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"1111111111"}
    uri = "https://www.barco.com/services/website/en/WarrantyLister/GetWarrantyResult"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("R9849880")):
        return "\nCase10: R9849880"
    else:
        return 0   



def get_web_data08():
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":"11111111111"}
    uri = "https://www.barco.com/services/website/en/WarrantyLister/GetWarrantyResult"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("We are sorry, there is no warranty information available about this product, if you need more information about this, please")):
        return "\nCase11: We are sorry, there is no warranty information available about this product, if you need more information about this, please"
    else:
        return 0 


def get_web_BeyondBorder1024():
    str = ""
    for i in range(1024): 
        str = str+"1"
    print(str)    
    header = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:51.0) Gecko/20100101 Firefox/51.0'}
    data = {"SerialNumber":f"{str}"}
    uri = "https://www.barco.com/en/clickshare/support/warranty-info"
    rs = requests.session()
    res = rs.post(uri, data=data, headers=header, timeout=300)
    html_data = ''
    if res.status_code == 200:
        print('OK')
        html_data = res.text
        print(html_data)
    else:
        print('Server error')
    if(html_data.find("Please enter a valid serial number")):
        return "\nCase11: Please enter a valid serial number"
    else:
        return "fail"


if __name__ == '__main__':
    getEmptyC()         #  0個1
    get_web_data1()     #  1個1
    get_web_data2()     #  2個1
    get_web_data3()     #  3個1
    get_web_data4()     #  4個1
    get_web_data5()     #  5個1
    get_web_data6()     #  6個1
    get_web_data07()    # 10個1
    get_web_data08()    # 11個1
    get_web_BeyondBorder1024()  # 輸入1024個1