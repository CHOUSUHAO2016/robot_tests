# _*_ coding:utf-8 _*_
import os, subprocess, tkinter.messagebox, re
import time
def cmd(command):
    """執行cmd命令"""
    subprocess.Popen(str(command), shell=True, stdout=subprocess.PIPE).wait()
    return False

def cmd_popen(command):
    """執行cmd命令，返回结果"""
    b = os.popen(command)
    return b.read()

def ResultCmd(command):
    """執行cmd命令，等待返回结果"""
    if command == '':
        print('沒有指令!')
        return
    else:
        p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, encoding='utf-8')
        p.wait()
        result = p.stdout.readlines()
        return result

def ResultCmdNoWait(command):
    if command == '':
        print('沒有指令!')
        return
    else:
        p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, encoding='utf-8')
        result = p.stdout.readlines()
        return result

def set_wifi(enable): 
    if(enable == "on"):
        os.popen("adb shell svc wifi enable").read()
    else:
        os.popen("adb shell svc wifi disable").read()
    if(int(os.popen("adb shell settings get global wifi_on").read().find('1')) == 0):
        enable = "wifi is on"
    else:
        enable = "wifi is off"
    return(enable)

def check_wifi(connect):
    os.popen("adb shell svc wifi enable").read()
    time.sleep(5)
    if(os.popen("adb shell ip addr show wlan0").read().find(connect) != -1):
        connect = "wifi is connect"
    else:
        connect = "wifi is disconnect"
    return(connect)

def check_diswifi():
    os.popen("adb shell svc wifi disable").read()
    time.sleep(5)
    if(int(os.popen("adb shell settings get global wifi_on").read().find('1')) == 0):
        return("wifi is connect")
    else:
        return("wifi is disconnect")


def check_rewifi(connect):
    os.popen("adb shell svc wifi disable").read()
    time.sleep(1)
    os.popen("adb shell svc wifi enable").read()
    time.sleep(10)
    if(os.popen("adb shell ip addr show wlan0").read().find(connect) != -1):
        connect = "wifi is connect"
    else:
        connect = "wifi is disconnect"
    return(connect)
# print(check_wifi_connect("192.168.0.255"))